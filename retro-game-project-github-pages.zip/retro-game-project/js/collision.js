export function hit(a,b){
  return Math.abs(a.x-b.x) < (a.w+b.w)/2 &&
         Math.abs(a.y-b.y) < (a.h+b.h)/2;
}
