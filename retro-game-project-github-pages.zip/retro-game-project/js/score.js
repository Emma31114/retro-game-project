import { CONFIG } from "./config.js";
export function speedForScore(score){
  return CONFIG.baseSpeed + Math.floor(score / CONFIG.speedStepEvery) * CONFIG.speedIncrease;
}
