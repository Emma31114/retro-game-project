export class Player {
  constructor(x, y, color) {
    this.x = x; this.y = y; this.w = 46; this.h = 78; this.color = color;
  }
  setColor(color){ this.color = color; }
  move(dx, width){
    this.x += dx;
    this.x = Math.max(25, Math.min(width - 25, this.x));
  }
  draw(ctx){
    ctx.save();
    ctx.translate(this.x, this.y);
    ctx.fillStyle = "#111";
    ctx.fillRect(-24,-39,48,78);
    ctx.fillStyle = this.color;
    ctx.fillRect(-18,-35,36,70);
    ctx.fillStyle = "#b3e5fc";
    ctx.fillRect(-13,-24,26,18);
    ctx.fillStyle = "#222";
    ctx.fillRect(-21,-28,6,18); ctx.fillRect(15,-28,6,18);
    ctx.fillRect(-21,12,6,18); ctx.fillRect(15,12,6,18);
    ctx.restore();
  }
}
