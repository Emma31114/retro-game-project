import { CONFIG, CARS } from "./config.js";
import { Player } from "./player.js";
import { Enemy } from "./enemy.js";
import { hit } from "./collision.js";
import { speedForScore } from "./score.js";
import { drawHUD } from "./ui.js";

export class Game {
  constructor(canvas){
    this.canvas=canvas; this.ctx=canvas.getContext("2d");
    this.selected=0; this.mode="select"; this.score=0; this.lives=CONFIG.lives;
    this.player=new Player(400,520,CARS[0].color); this.enemies=[];
    this.keys={}; this.last=0; this.spawnTimer=0;
    addEventListener("keydown",e=>this.key(e,true));
    addEventListener("keyup",e=>this.key(e,false));
  }
  key(e,down){
    if(["ArrowLeft","ArrowRight","Enter","Escape"].includes(e.key)) e.preventDefault();
    if(!down)return;
    if(this.mode==="select"){
      if(e.key==="ArrowLeft"){this.selected=(this.selected+CARS.length-1)%CARS.length;this.player.setColor(CARS[this.selected].color)}
      if(e.key==="ArrowRight"){this.selected=(this.selected+1)%CARS.length;this.player.setColor(CARS[this.selected].color)}
      if(e.key==="Enter") this.startGame();
    } else if(this.mode==="play"){
      if(e.key==="Escape") this.mode="select";
    } else if(this.mode==="gameover" && e.key==="Enter") this.startGame();
    this.keys[e.key]=true;
  }
  startGame(){
    this.mode="play"; this.score=0; this.lives=CONFIG.lives; this.enemies=[];
    this.player.x=400; this.spawnTimer=0;
  }
  start(){requestAnimationFrame(t=>this.loop(t))}
  loop(t){
    const dt=Math.min(32,t-this.last||16); this.last=t;
    this.update(dt); this.draw(); requestAnimationFrame(x=>this.loop(x));
  }
  update(dt){
    if(this.mode!=="play") return;
    const speed=speedForScore(this.score);
    if(this.keys.ArrowLeft)this.player.move(-6,800);
    if(this.keys.ArrowRight)this.player.move(6,800);
    this.spawnTimer-=dt;
    if(this.spawnTimer<=0){
      this.spawnTimer=Math.max(350,900-speed*70);
      this.enemies.push(new Enemy(80+Math.random()*640,-60, CARS[Math.floor(Math.random()*CARS.length)].color));
    }
    for(const e of this.enemies)e.update(speed);
    for(let i=this.enemies.length-1;i>=0;i--){
      const e=this.enemies[i];
      if(hit(this.player,e)){
        this.enemies.splice(i,1); this.lives--;
        if(this.lives<=0)this.mode="gameover";
      } else if(e.y>660){
        this.enemies.splice(i,1); this.score+=10;
      }
    }
  }
  draw(){
    const c=this.ctx;
    c.clearRect(0,0,800,600);
    c.fillStyle="#287a2d";c.fillRect(0,0,800,600);
    c.fillStyle="#444";c.fillRect(110,0,580,600);
    c.strokeStyle="#fff";c.lineWidth=5;c.setLineDash([30,25]);
    c.beginPath();c.moveTo(300,0);c.lineTo(300,600);c.moveTo(500,0);c.lineTo(500,600);c.stroke();c.setLineDash([]);
    if(this.mode==="select"){
      c.fillStyle="#000b";c.fillRect(150,110,500,380);
      c.fillStyle="#fff";c.textAlign="center";
      c.font="32px system-ui";c.fillText("選擇你的賽車",400,165);
      this.player.x=400;this.player.y=300;this.player.draw(c);
      c.font="28px system-ui";c.fillText(CARS[this.selected].name,400,405);
      c.font="18px system-ui";c.fillText("← / → 切換　Enter 開始",400,445);
      c.textAlign="start"; return;
    }
    if(this.mode==="play"){
      this.player.y=520;this.player.draw(c);this.enemies.forEach(e=>e.draw(c));
      drawHUD(c,this.score,this.lives,speedForScore(this.score),CARS[this.selected].name,this.mode);
    }
    if(this.mode==="gameover"){
      this.player.y=520;this.player.draw(c);
      c.fillStyle="#000c";c.fillRect(170,190,460,220);
      c.fillStyle="#fff";c.textAlign="center";
      c.font="42px system-ui";c.fillText("遊戲結束",400,255);
      c.font="24px system-ui";c.fillText(`最終分數：${this.score}`,400,305);
      c.font="18px system-ui";c.fillText("Enter 重新開始　Esc 返回選車",400,355);
      c.textAlign="start";
    }
  }
}
