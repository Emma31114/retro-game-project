export class Enemy {
  constructor(x, y, color="#f44336"){
    this.x=x; this.y=y; this.w=46; this.h=78; this.color=color;
  }
  update(speed){ this.y += speed; }
  draw(ctx){
    ctx.save(); ctx.translate(this.x,this.y);
    ctx.fillStyle="#111"; ctx.fillRect(-24,-39,48,78);
    ctx.fillStyle=this.color; ctx.fillRect(-18,-35,36,70);
    ctx.fillStyle="#90caf9"; ctx.fillRect(-13,-24,26,18);
    ctx.fillStyle="#222";
    ctx.fillRect(-21,-28,6,18); ctx.fillRect(15,-28,6,18);
    ctx.fillRect(-21,12,6,18); ctx.fillRect(15,12,6,18);
    ctx.restore();
  }
}
