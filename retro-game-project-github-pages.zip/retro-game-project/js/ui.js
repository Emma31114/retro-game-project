export function drawHUD(ctx, score, lives, speed, carName, mode){
  ctx.fillStyle="#000b"; ctx.fillRect(0,0,800,58);
  ctx.fillStyle="#fff"; ctx.font="18px system-ui";
  ctx.fillText(`車輛：${carName}`,18,25);
  ctx.fillText(`分數：${score}`,190,25);
  ctx.fillText(`機會：${lives}`,320,25);
  ctx.fillText(`速度：${speed.toFixed(2)}`,445,25);
  ctx.font="14px system-ui"; ctx.fillStyle="#ddd";
  ctx.fillText(mode==="play" ? "← → 移動　Esc 返回選車" : "← → 選車　Enter 開始",18,48);
}
