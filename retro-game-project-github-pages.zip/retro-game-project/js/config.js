export const CONFIG = {
  width: 800,
  height: 600,
  baseSpeed: 3.5,
  speedStepEvery: 50,
  speedIncrease: 0.75,
  lives: 5
};

export const CARS = [
  { name: "閃電", color: "#e53935" },
  { name: "藍焰", color: "#1e88e5" },
  { name: "黃金", color: "#fdd835" },
  { name: "翡翠", color: "#43a047" },
  { name: "紫電", color: "#8e24aa" }
];
